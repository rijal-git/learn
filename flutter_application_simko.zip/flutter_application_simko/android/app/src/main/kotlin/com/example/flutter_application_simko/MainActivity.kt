package com.example.flutter_application_simko

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
