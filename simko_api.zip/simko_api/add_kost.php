<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include 'koneksi.php';

$kamar     = $_POST['kamar']     ?? '';
$ukuran    = $_POST['ukuran']    ?? '';
$fasilitas = $_POST['fasilitas'] ?? '';
$harga     = $_POST['harga']     ?? '';
$status    = $_POST['status']    ?? 'Kosong';
$gambar    = $_POST['gambar']    ?? 'default.jpg';   // minimal isi

if(!$kamar||!$ukuran||!$fasilitas||!$harga){
  echo json_encode(['success'=>false,'message'=>'Semua field wajib diisi']); exit;
}

$stmt = mysqli_prepare($conn,
  "INSERT INTO kost (kamar, ukuran, fasilitas, harga, status, gambar)
   VALUES (?,?,?,?,?,?)");
mysqli_stmt_bind_param($stmt,'sssiss',
  $kamar,$ukuran,$fasilitas,$harga,$status,$gambar);

if(mysqli_stmt_execute($stmt)){
  echo json_encode(['success'=>true,'message'=>'Kost berhasil ditambahkan']);
}else{
  echo json_encode(['success'=>false,'message'=>'Gagal menambah kost']);
}
?>
