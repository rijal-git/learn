<?php
include 'koneksi.php';
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$bulan = $_GET['bulan'] ?? '';
if (empty($bulan)) {
    echo json_encode(['success' => false, 'message' => 'Bulan tidak valid.']);
    exit;
}

$sql = "SELECT p.id AS id_pembayaran, penghuni.nama AS nama, p.nominal AS jumlah, p.tanggal, p.status
        FROM pembayaran AS p
        JOIN penghuni ON p.id_penghuni = penghuni.id
        WHERE LOWER(p.bulan) = LOWER(?)
        AND p.status IN ('Lunas', 'Menunggu Konfirmasi') -- ✅ ubah bagian ini
        ORDER BY p.tanggal DESC";


$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $bulan);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(['success' => true, 'data' => $data]);
