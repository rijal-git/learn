<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
include 'koneksi.php'; // Koneksi ke database

// Ambil data ID kost yang akan dihapus
$id = $_POST['id'];

// Validasi input
if (empty($id)) {
    echo json_encode(['success' => false, 'message' => 'ID Kost tidak valid']);
    exit;
}

// Query untuk menghapus data kost
$query = "DELETE FROM kost WHERE id = '$id'";
if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true, 'message' => 'Kost berhasil dihapus']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus kost']);
}
?>
