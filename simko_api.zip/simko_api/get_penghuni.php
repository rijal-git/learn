<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
// db_connect.php
$host = "localhost";
$user = "root";
$pass = "";
$db = "simko_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header('Content-Type: application/json');

$sql = "SELECT id, nama, email FROM penghuni";
$result = $conn->query($sql);

$penghuni = [];
while ($row = $result->fetch_assoc()) {
    $penghuni[] = $row;
}

echo json_encode($penghuni);
$conn->close();
?>
