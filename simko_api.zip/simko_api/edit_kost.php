<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
include 'koneksi.php';

$id        = $_POST['id']        ?? '';
$kamar     = $_POST['kamar']     ?? '';
$ukuran    = $_POST['ukuran']    ?? '';
$fasilitas = $_POST['fasilitas'] ?? '';
$harga     = $_POST['harga']     ?? '';
$status    = $_POST['status']    ?? 'Kosong';
$gambar    = $_POST['gambar']    ?? '';

if(!$id||!$kamar||!$ukuran||!$fasilitas||!$harga){
  echo json_encode(['success'=>false,'message'=>'Semua field wajib diisi']); exit;
}

$stmt = mysqli_prepare($conn,
  "UPDATE kost SET kamar=?, ukuran=?, fasilitas=?, harga=?, status=?, gambar=?
   WHERE id=?");
mysqli_stmt_bind_param($stmt,'sssissi',
  $kamar,$ukuran,$fasilitas,$harga,$status,$gambar,$id);

if(mysqli_stmt_execute($stmt)){
  echo json_encode(['success'=>true,'message'=>'Kost berhasil diperbarui']);
}else{
  echo json_encode(['success'=>false,'message'=>'Gagal memperbarui kost']);
}
?>
