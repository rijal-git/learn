<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
include 'koneksi.php';

$id = $_GET['id_penghuni'] ?? '';
if (!$id){ echo '[]'; exit; }

$stmt = mysqli_prepare($conn,
  "SELECT ds.*, k.kamar, k.ukuran, k.fasilitas, k.harga, k.gambar
   FROM data_sewa ds 
   JOIN kost k ON k.id = ds.id_kost
   WHERE ds.id_penghuni=? AND ds.status='Aktif' LIMIT 1");
mysqli_stmt_bind_param($stmt,'i',$id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

echo json_encode(mysqli_fetch_all($res,MYSQLI_ASSOC));
