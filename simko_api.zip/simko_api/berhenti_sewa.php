<?php
include 'koneksi.php';
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$id_penghuni = $_POST['id_penghuni'];
$alasan = $_POST['alasan'];

$query = "INSERT INTO permintaan_berhenti (id_penghuni, alasan, status) VALUES ('$id_penghuni', '$alasan', 'Menunggu Konfirmasi')";
$result = mysqli_query($conn, $query);

echo $result ? 'success' : 'error';
?>
