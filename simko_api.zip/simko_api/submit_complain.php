<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
$host = "localhost";
$username = "root";
$password = "";
$dbname = "simko_db";

// Membuat koneksi
$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mendapatkan data dari request
$kamar = $_POST['kamar'];
$tentang = $_POST['tentang'];
$pesan = $_POST['pesan'];

// Query untuk menyimpan komplain
$sql = "INSERT INTO komplain (kamar, tentang, pesan) VALUES ('$kamar', '$tentang', '$pesan')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menyimpan komplain']);
}

$conn->close();
?>
