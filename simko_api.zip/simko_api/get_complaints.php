<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$host = "localhost";
$username = "root";
$password = "";
$dbname = "simko_db";

// Membuat koneksi
$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil data komplain
$sql = "SELECT * FROM komplain";
$result = $conn->query($sql);

$komplain = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $komplain[] = [
            'nama' => $row['nama'],
            'tanggal' => $row['created_at'], // Tanggal komplain diambil dari timestamp
            'tentang' => $row['tentang'],
            'pesan' => $row['pesan'],
            'kamar' => $row['kamar'],
        ];
    }
    echo json_encode($komplain);
} else {
    echo json_encode([]);
}

$conn->close();
?>
